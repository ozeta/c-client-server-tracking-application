#ifndef LIBRARYC_H
#define LIBRARYC_H

#include "library.h"

#endif
